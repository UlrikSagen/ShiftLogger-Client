package model;

public class Settigns {
    
}
