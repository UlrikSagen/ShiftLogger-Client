package model;


public class Tariff {
    String tariff;
    public Tariff(String tariff){
        this.tariff = tariff;
    }

    public String getTariff(){
        return this.tariff;
    }
}
